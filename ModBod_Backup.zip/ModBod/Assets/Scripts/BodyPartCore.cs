﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BodyPartCore : BodyPart {


    public override void OnProjectileHit(Projectile p)
    {
        
    }

}
